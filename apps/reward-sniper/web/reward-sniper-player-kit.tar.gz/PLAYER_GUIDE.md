# Reward Sniper player guide

Reward Sniper is a shared DLMM-style market. You receive one unscored practice round followed by three
scored rounds. Each scored round awards your team its share of the reward extracted in that round;
the final event score is the sum of those normalized round shares.

## Round loop

Each tick has two phases:

1. **Commit:** select a bin and lock one exact order. Other teams cannot see the order.
2. **Reveal:** reveal the same order and nonce. Accepted reveals enter one deterministic settlement
   batch after the phase closes.

A missed reveal does not settle. A team can resolve at most one action per tick.

Each round gives your team three Sniper Tickets and a funded liquidity balance. A successful ticket
order consumes one ticket and the submitted liquidity. A pressure swap consumes the tick but not a
ticket; it moves the active bin and directly extracts no reward. The market parameters, initial
history, active bin, and team ticket balances rotate at the next round. Practice extraction is
discarded when scoring begins. Scored rounds start from unseen regimes, so an exact sequence learned
in practice is not a reusable answer.

Public bin window labels and heat are observations, not internal accumulator values. Every team also
receives one incomplete telemetry card. Treat it as evidence, not an oracle.

Passive inspection is unlimited. State-changing actions are limited to one per tick, and only three
high-value ticket orders are available each round. There is no hypothetical-outcome or reset API.

## Deliverables

Live ranking is determined only by normalized extraction share. Prize eligibility also requires the
team to retain its searcher source, explain the vulnerable reward behavior, describe the evidence
used to infer it, and identify one successful settled extraction after the event.

## Limited client SDK

`sdk.mjs` exposes legitimate session, inspect, lock, reveal, and scoreboard flows without any market
optimizer:

```js
import { RewardSniperClient } from "./sdk.mjs";

const client = new RewardSniperClient({
  baseUrl: "https://reward-sniper.example/",
  accessToken: process.env.REWARD_SNIPER_ACCESS_TOKEN,
});

const market = await client.market();
const locked = await client.lockTicket({ binId: 2, liquidity: 900 });

// Wait until market.phase === "reveal", then:
await client.reveal(locked);
```

Keep the complete locked-order object and nonce until settlement. Losing it means the commitment cannot
be revealed. Production sessions are issued by launching the challenge from the CTF26 event portal.
